CACHE_DIR = '/var/mobile/Library/Caches/com.r333d.jjjj'
RES_PATH = PATH..'/res'


local config = {}
return config
