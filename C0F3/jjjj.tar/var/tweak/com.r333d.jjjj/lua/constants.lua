SUBSTRATE_DIR = '/Library/MobileSubstrate/DynamicLibraries'
MASTER_REPO_LIST = 'https://raw.githubusercontent.com/jonluca/MasterRepo/master/masterrepoeasyinstall/etc/apt/sources.list.d/MasterRepo.list'
